<header>
    <div class="h-top"></div>
    <div class="h-body h-bg">
    	<menu class="clearfix">
    		<ul class="pull-left">
    			<li><a href="#" class="border-r"><span class="muiten"></span> Giới thiệu<br>sản phẩm</a></li>
    			<li><a href="#" class="border-r"><span class="muiten"></span>Chuyên gia<br>tư vấn</a></li>
    			<li><a href="#"><span class="muiten"></span>Câu chuyện<br>sức khỏe</a></li>
    		</ul>
    		<ul class="pull-right">
    			<li><a href="#" class="border-r"><span class="muiten"></span>Chứng nhận<br>liên quan</a></li>
    			<li><a href="#" class="border-r"><span class="muiten"></span>Hướng dẫn<br>sử dụng</a></li>
    			<li><a href="#"><span class="muiten"></span>Đặt mua<br>online</a></li>
    		</ul>
            <h1 class="text-center text-uppercase">lục khang</h1>
    	</menu>
    </div>
    <div class="h-footer">
    	<a href="#" class="bg">
    		<img src="{{ asset('public/image/luckhangcom/header/2.png') }}" alt="">	
    	</a>
 		<span>Đường dây nóng tư vấn, đặt hàng toàn quốc</span>
 		<a href="#">0123 456 789</a>
    </div>
</header>