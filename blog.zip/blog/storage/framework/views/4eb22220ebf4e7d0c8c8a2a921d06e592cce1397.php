<!DOCTYPE html>
<html lang="vi">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="language" content="vi" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="classification" content="hospital" />
    <meta name="distribution" content="Global" />
    <meta name="rating" content="General" />
    <meta name="robots" content="index, follow" />
    <meta name="creator" content="Phòng khám Nam Khang" />
    <meta name="publisher" content="Phòng khám Nam Khang" />
    <meta name="author" content="">
    <!-- csrf -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- facebook -->
    <meta property="og:site_name" content="Phòng Khám Nam Khang" />
    <meta property="og:type" content="article" />
    <meta property="og:locale " content="vi_VN">
    <meta property="fb:app_id" content="">
    <meta property="fb:admins" content="">
    <!-- link rss,sitemap -->
    <!-- link icon -->
    <link rel="shortcut icon" href="#" type="image/x-icon">
    <?php echo $__env->yieldContent('title'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/hover/css/hover.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/luckhangcom/bodyMobile.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/luckhangcom/headerMobile.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/luckhangcom/footerMobile.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/luckhangcom/homeMobile.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <script type="text/javascript" src="<?php echo e(asset('public/js/jquery-1.12.3.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/jquery.form.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/jquery.popupoverlay.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/jquery-scrolltofixed-min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/slick/slick.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</head>
<body>
    <main class="container">
        <?php echo $__env->make('luckhangcom.mobile.headerMobile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('luckhangcom.mobile.footerMobile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </main>
</body>
</html>