<?php $__env->startSection('title'); ?>
<title>Lục khang</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="h-home">
		hi mobile
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("luckhangcom.mobile.bodyMobile", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>