<footer>
	<div class="container">
		<p class="theend text-center">
			* Thông tin ở trang web này không có tác dụng thay thế chỉ dẫn của bác sĩ hoặc lấy làm căn cứ để điều trị ,
			xin hãy làm theo chỉ dẫn của bác sĩ để đảm bảo tính an toàn khi sử dụng thuốc *
		</p>
	</div>
</footer>